//! Item ids and labels, footage items (solids and files), precomp linkage, and the name and size
//! of a layer's source.

use crate::container::bytes::{be_f32, be_f64, be_u32, cstr, le_u32, text};
use crate::container::chunk::Chunk;
use crate::container::header::Rational;
use crate::container::typed::{Item, ItemKind, Layer, Project};

/// The footage data of an item (`LIST Pin ` with `sspc`, `opti` and, for files, `Als2/alas`).
#[derive(Debug, Clone, PartialEq)]
pub struct Footage {
    /// The 4-character file type tag at byte 22 of `sspc` (`Soli` for a solid, `png!` for a png).
    pub file_type: String,
    /// The width in pixels (`u32` at byte 30 of `sspc`).
    pub width: u32,
    /// The height in pixels (`u32` at byte 34 of `sspc`).
    pub height: u32,
    /// The display name stored in `opti` (the item's own `Utf8` name is empty for footage): at byte
    /// 26 for a solid and at byte 58 for a file.
    pub name: Option<String>,
    /// True for a solid (tag `Soli` at the start of `opti`).
    pub is_solid: bool,
    /// The colour of a solid as ARGB floats 0..1 (`opti` bytes 10, 14, 18, 22); a red solid is
    /// `[1, 1, 0, 0]`.
    pub solid_argb: Option<[f32; 4]>,
    /// The file path from the alias JSON (`Als2/alas`, key `fullpath`); none for solids. For an
    /// image sequence it is the sequence **folder**.
    pub path: Option<String>,
    /// The duration in seconds as stored (`sspc` `u32` at byte 38 over `u32` at byte 42; unreduced):
    /// 0/1 for stills, 48000/48000 for the 1 s WAV (the sample rate is the denominator), 3/30 for
    /// the three-frame image sequence (the frame rate is the denominator).
    pub duration: Option<Rational>,
    /// The native frame rate (`sspc` `u32` at byte 56): 30 for the image sequence, 0 for stills,
    /// audio and solids (also 0 when the byte is missing).
    pub native_frame_rate: u32,
    /// The bits per pixel (`sspc` `u32` at byte 60): 32 for an RGBA still, 24 for an RGB sequence,
    /// 0 for solids and audio.
    pub bits_per_pixel: u32,
    /// The size in bytes of the source file(s) (`sspc` `u32` at byte 208): 149 for the png, 96044
    /// for the WAV (44 + 48000 x 2), 504 for three 168-byte png files.
    pub file_size: u32,
    /// The audio sample rate (`sspc` `f64` at byte 160, 48000.0 for the WAV and for an mp4 with
    /// 48 kHz sound); `None` for footage without audio.
    pub audio_sample_rate: Option<f64>,
    /// True when the alias points at a folder (`"target_is_folder":true`): an image sequence is ONE
    /// item whose alias is its folder and whose `opti` holds the first file name.
    pub is_sequence: bool,
}

impl Footage {
    /// The number of frames of an image sequence (`duration * native_frame_rate`: 3/30 s at 30 fps is
    /// 3); `None` for anything else.
    pub fn sequence_frame_count(&self) -> Option<u32> {
        if !self.is_sequence {
            return None;
        }
        let d = self.duration?;
        let frames = i128::from(d.num).checked_mul(i128::from(self.native_frame_rate))?;
        let den = i128::from(d.den);
        if den <= 0 || frames % den != 0 {
            return None;
        }
        u32::try_from(frames / den).ok()
    }

    /// The solid's colour as fractions R, G, B.
    pub fn solid_rgb(&self) -> Option<[f32; 3]> {
        let [_, r, g, b] = self.solid_argb?;
        Some([r, g, b])
    }
}

/// The boolean value of `"key"` in a flat JSON object (`true` / `false`); `None` when missing.
pub(crate) fn json_bool(json: &[u8], key: &str) -> Option<bool> {
    let needle = format!("\"{key}\":");
    let needle = needle.as_bytes();
    let at = json.windows(needle.len()).position(|w| w == needle)?;
    let rest = json.get(at.checked_add(needle.len())?..)?;
    if rest.starts_with(b"true") {
        Some(true)
    } else if rest.starts_with(b"false") {
        Some(false)
    } else {
        None
    }
}

/// The string value of `"key"` in a flat JSON object, with the standard escapes decoded.
/// Returns `None` when the key is missing or the value is not a string. The key is the first
/// occurrence of `"key"` that is followed by `:` (the same text as a value is skipped).
pub(crate) fn json_string(json: &[u8], key: &str) -> Option<String> {
    let needle = format!("\"{key}\"");
    let needle = needle.as_bytes();
    let mut from = 0usize;
    loop {
        let at = from.checked_add(json.get(from..)?.windows(needle.len()).position(|w| w == needle)?)?;
        let after = at.checked_add(needle.len())?;
        if let Some(v) = json_string_at(json, after) {
            return Some(v);
        }
        from = at.checked_add(1)?;
    }
}

/// The string value right after a key ending at `i` (`: "…"`), or `None` when none follows.
fn json_string_at(json: &[u8], mut i: usize) -> Option<String> {
    let skip_ws = |i: &mut usize| {
        while json.get(*i).is_some_and(|c| c.is_ascii_whitespace()) {
            *i = i.saturating_add(1);
        }
    };
    skip_ws(&mut i);
    if json.get(i) != Some(&b':') {
        return None;
    }
    i = i.saturating_add(1);
    skip_ws(&mut i);
    if json.get(i) != Some(&b'"') {
        return None;
    }
    i = i.saturating_add(1);
    let mut out: Vec<u8> = Vec::new();
    loop {
        let c = *json.get(i)?;
        i = i.saturating_add(1);
        match c {
            b'"' => return Some(text(&out)),
            b'\\' => {
                let e = *json.get(i)?;
                i = i.saturating_add(1);
                match e {
                    b'n' => out.push(b'\n'),
                    b't' => out.push(b'\t'),
                    b'r' => out.push(b'\r'),
                    b'b' => out.push(8),
                    b'f' => out.push(12),
                    b'u' => {
                        let hex4 = |at: usize| {
                            json.get(at..at.checked_add(4)?).and_then(|h| std::str::from_utf8(h).ok()).and_then(|h| u32::from_str_radix(h, 16).ok())
                        };
                        let mut code = hex4(i)?;
                        i = i.saturating_add(4);
                        // A character outside the BMP is a high surrogate and a `\u` low surrogate.
                        if (0xd800..0xdc00).contains(&code)
                            && json.get(i..i.saturating_add(2)) == Some(b"\\u")
                            && let Some(lo) = hex4(i.saturating_add(2)).filter(|lo| (0xdc00..0xe000).contains(lo))
                        {
                            code = 0x10000 + ((code - 0xd800) << 10) + (lo - 0xdc00);
                            i = i.saturating_add(6);
                        }
                        let ch = char::from_u32(code).unwrap_or('\u{fffd}');
                        let mut buf = [0u8; 4];
                        out.extend_from_slice(ch.encode_utf8(&mut buf).as_bytes());
                    }
                    other => out.push(other),
                }
            }
            other => out.push(other),
        }
    }
}

/// The numbering of an image sequence item (353, 603), or its file list when it was imported with
/// Force alphabetical order.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SequenceInfo {
    /// The file name before the frame number (`seq_`, `shot_`): the first `Utf8` after the alias.
    /// An empty prefix is not stored (`0001.png`): the one `Utf8` is then the suffix.
    pub prefix: String,
    /// The file name after the frame number (`.png`, `.exr`): the second `Utf8` after the alias.
    pub suffix: String,
    /// The first and last frame number (`sspc` `u32` at 172 and 176: 1 and 3 in 353, 101 and 103
    /// in 603; both `0xFFFFFFFF` for a sequence with a file list).
    pub start: u32,
    pub end: u32,
    /// The digits of the frame number (`sspc` `u32` at 180: 3 for `seq_001`, 4 for `shot_0101`).
    pub digits: u32,
    /// The file names in order for a sequence imported with Force alphabetical order (`LIST StVc`
    /// after the alias: `StVS` with the count as a little-endian `u32`, then one `Utf8` per file);
    /// empty for a numbered sequence. When set, it replaces the numbering.
    pub files: Vec<String>,
}

impl SequenceInfo {
    /// The file name of frame `n` (`shot_0101.exr`).
    pub fn file_name(&self, n: u32) -> String {
        let width = usize::try_from(self.digits.min(16)).unwrap_or(0);
        format!("{}{n:0width$}{}", self.prefix, self.suffix)
    }

    /// The number of files: the listed files, or the frame numbers from start to end (0 when the
    /// end lies before the start).
    pub fn frame_count(&self) -> u32 {
        if self.files.is_empty() {
            self.end.checked_sub(self.start).map_or(0, |d| d.saturating_add(1))
        } else {
            u32::try_from(self.files.len()).unwrap_or(u32::MAX)
        }
    }

    /// The name of the `i`-th file (from 0): from the file list, or numbered from `start`; `None`
    /// past the last file.
    pub fn nth_file_name(&self, i: u32) -> Option<String> {
        if self.files.is_empty() {
            let n = self.start.checked_add(i).filter(|n| *n <= self.end)?;
            Some(self.file_name(n))
        } else {
            self.files.get(usize::try_from(i).ok()?).cloned()
        }
    }
}

/// The file names of a `LIST StVc` (Force alphabetical order): the `Utf8` children in order, at most
/// as many as the count in `StVS` (little-endian `u32`) says. Empty names count toward that number
/// and are then skipped. Without a readable count (no `StVS`, or one shorter than 4 bytes) the list
/// is unreadable (empty). A name that is not a plain file name (holding `/`, `\`, `:` or a control
/// character such as NUL, or being `.` or `..`) makes the whole list unreadable (empty): the names
/// are joined to the folder.
fn sequence_file_list(list: &Chunk<'_>) -> Vec<String> {
    // After Effects writes the count first (the one sample); a list without a readable count is
    // not read rather than guessed.
    let Some(count) = list.child(b"StVS").and_then(|c| c.bytes()).and_then(|b| le_u32(b, 0)).and_then(|n| usize::try_from(n).ok()) else {
        return Vec::new();
    };
    let names: Vec<String> =
        list.children().iter().filter(|c| c.is(b"Utf8")).filter_map(|c| c.bytes()).take(count).map(text).filter(|n| !n.is_empty()).collect();
    if names.iter().any(|n| n.contains(|c: char| matches!(c, '/' | '\\' | ':') || c.is_control()) || n == "." || n == "..") {
        return Vec::new();
    }
    names
}

/// The prefix and suffix of a sequence whose naming holds one `Utf8` (`part`): After Effects leaves
/// out an empty prefix (`0001.png` stores only `.png`). The stored first file name (`opti`) decides:
/// a name starting with `part` has it as the prefix, one ending with it as the suffix. Without that
/// evidence, a `part` starting with `.` is the suffix (an extension); anything else is not read.
fn single_name_part(part: &str, first_file: Option<&str>) -> Option<(String, String)> {
    if let Some(first) = first_file.filter(|_| !part.is_empty()) {
        match (first.starts_with(part), first.ends_with(part)) {
            (true, false) => return Some((part.to_string(), String::new())),
            (false, true) => return Some((String::new(), part.to_string())),
            _ => {}
        }
    }
    part.starts_with('.').then(|| (String::new(), part.to_string()))
}

impl<'f, 'a> Item<'f, 'a> {
    /// The numbering of an image sequence (an item whose alias is a folder); `None` for anything
    /// else.
    pub fn sequence_info(&self) -> Option<SequenceInfo> {
        let f = self.footage()?;
        if !f.is_sequence {
            return None;
        }
        let pin = self.chunk.child_list(b"Pin ")?;
        let sspc = pin.child(b"sspc")?.bytes()?;
        let kids = pin.children();
        let after = kids.iter().position(|c| c.is_list(b"Als2"))?;
        let naming = || kids.iter().skip(after.saturating_add(1)).take_while(|c| !c.is(b"opti"));
        let (start, end, digits) = (be_u32(sspc, 172)?, be_u32(sspc, 176)?, be_u32(sspc, 180)?);
        // Force alphabetical order: the file list replaces the numbering.
        if let Some(list) = naming().find(|c| c.is_list(b"StVc")) {
            let files = sequence_file_list(list);
            if files.is_empty() {
                return None;
            }
            return Some(SequenceInfo { prefix: String::new(), suffix: String::new(), start, end, digits, files });
        }
        let names: Vec<String> = naming().filter(|c| c.is(b"Utf8")).filter_map(|c| c.bytes()).map(text).take(2).collect();
        let (prefix, suffix) = match names.as_slice() {
            [prefix, suffix] => (prefix.clone(), suffix.clone()),
            // An empty prefix is not stored (`0001.png` has only `.png`).
            [one] => single_name_part(one, f.name.as_deref())?,
            _ => return None,
        };
        Some(SequenceInfo { prefix, suffix, start, end, digits, files: Vec::new() })
    }

    /// The rate a clip is conformed to (Interpret Footage ▸ Conform to frame rate; `sspc` `u32` at
    /// byte 146): 30 for the 25 fps mp4 conformed to 30 (645), `None` when not conformed (0 in 644,
    /// 606) or for an item without footage data. The effective rate is then also at byte 150 while
    /// the stored duration (bytes 38 / 42) and byte 56 stay native. A conformed image sequence
    /// stores the new rate in bytes 42, 56 and 150 instead and keeps 0 here (615).
    pub fn conform_frame_rate(&self) -> Option<u32> {
        let sspc = self.chunk.child_list(b"Pin ")?.child(b"sspc")?.bytes()?;
        be_u32(sspc, 146).filter(|r| *r > 0)
    }

    /// The item id: the big-endian `u32` at byte 16 of `idta` (what a layer's source id refers to).
    pub fn id(&self) -> Option<u32> {
        be_u32(self.chunk.child(b"idta")?.bytes()?, 16)
    }

    /// The label colour index, byte 58 of `idta` (15 for a composition made by precomposing).
    pub fn label(&self) -> Option<u8> {
        self.chunk.child(b"idta")?.bytes()?.get(58).copied()
    }

    /// The ids of the compositions this item uses as precomp layers: the little-endian `u32` of
    /// each `idpi` chunk.
    pub fn used_item_ids(&self) -> Vec<u32> {
        self.chunk.children().iter().filter(|c| c.is(b"idpi")).filter_map(|c| le_u32(c.bytes()?, 0)).collect()
    }

    /// The footage data of a footage item.
    pub fn footage(&self) -> Option<Footage> {
        if self.kind()? != ItemKind::Footage {
            return None;
        }
        let pin = self.chunk.child_list(b"Pin ")?;
        let sspc = pin.child(b"sspc")?.bytes()?;
        let opti = pin.child(b"opti")?.bytes()?;
        let is_solid = opti.get(..4) == Some(&b"Soli"[..]);
        let alias = pin.child_list(b"Als2").and_then(|als| als.child(b"alas")).and_then(|alas| alas.bytes());
        let path = alias.and_then(|json| json_string(json, "fullpath"));
        let is_sequence = alias.and_then(|json| json_bool(json, "target_is_folder")).unwrap_or(false);
        let solid_argb = if is_solid { Some([be_f32(opti, 10)?, be_f32(opti, 14)?, be_f32(opti, 18)?, be_f32(opti, 22)?]) } else { None };
        Some(Footage {
            file_type: cstr(sspc, 22, 4)?,
            width: be_u32(sspc, 30)?,
            height: be_u32(sspc, 34)?,
            name: cstr(opti, if is_solid { 26 } else { 58 }, 256).filter(|n| !n.is_empty()),
            is_solid,
            solid_argb,
            path,
            duration: be_u32(sspc, 38).zip(be_u32(sspc, 42)).map(|(num, den)| Rational { num: i64::from(num), den: i64::from(den) }),
            native_frame_rate: be_u32(sspc, 56).unwrap_or(0),
            bits_per_pixel: be_u32(sspc, 60).unwrap_or(0),
            file_size: be_u32(sspc, 208).unwrap_or(0),
            audio_sample_rate: be_f64(sspc, 160).filter(|r| r.is_finite() && *r > 0.0),
            is_sequence,
        })
    }

    /// The name this item shows in the project: the item name, or for footage the name stored in
    /// `opti`.
    pub fn display_name(&self) -> Option<String> {
        self.name().or_else(|| self.footage().and_then(|f| f.name))
    }
}

impl<'f, 'a> Project<'f, 'a> {
    /// The item with this id (`idta` byte 16), searching every item including those in folders.
    pub fn item_by_id(&self, id: u32) -> Option<Item<'f, 'a>> {
        self.all_items().into_iter().find(|i| i.id() == Some(id))
    }

    /// The item a layer is made from (its source id), e.g. the solid, the footage or the precomp.
    pub fn layer_source(&self, layer: &Layer<'f, 'a>) -> Option<Item<'f, 'a>> {
        self.item_by_id(layer.header()?.source_id?)
    }

    /// The name a layer shows: its own name, or its source's name when it has none.
    pub fn layer_display_name(&self, layer: &Layer<'f, 'a>) -> Option<String> {
        layer.name().or_else(|| self.layer_source(layer)?.display_name())
    }

    /// The pixel size of a layer's source: a footage item's width and height, or a precomp's
    /// composition size.
    pub fn layer_source_size(&self, layer: &Layer<'f, 'a>) -> Option<(u32, u32)> {
        let source = self.layer_source(layer)?;
        match source.kind()? {
            ItemKind::Footage => source.footage().map(|f| (f.width, f.height)),
            ItemKind::Composition => source.comp()?.header().map(|h| (u32::from(h.width), u32::from(h.height))),
            ItemKind::Folder | ItemKind::Other(_) => None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::json_string;

    #[test]
    fn reads_a_string_with_escapes() {
        let json = br#"{"a":1,"fullpath":"C:\\dir\\f\u00e9.png","b":"x"}"#;
        assert_eq!(json_string(json, "fullpath").as_deref(), Some(r"C:\dir\fé.png"));
        assert_eq!(json_string(json, "b").as_deref(), Some("x"));
        assert_eq!(json_string(json, "missing"), None);
        assert_eq!(json_string(br#"{"a" : "spaced"}"#, "a").as_deref(), Some("spaced"));
        // The key's text as an earlier value is not the key.
        assert_eq!(json_string(br#"{"a":"fullpath","fullpath":"x"}"#, "fullpath").as_deref(), Some("x"));
        // A surrogate pair is one character; a lone half stays U+FFFD.
        assert_eq!(json_string(br#"{"a":"x\ud83d\ude00y"}"#, "a").as_deref(), Some("x😀y"));
        assert_eq!(json_string(br#"{"a":"\ud83dz"}"#, "a").as_deref(), Some("\u{fffd}z"));
        assert_eq!(json_string(br#"{"a":"\ude00"}"#, "a").as_deref(), Some("\u{fffd}"));
    }

    #[test]
    fn damaged_json_never_panics() {
        for json in [
            &br#"{"fullpath":"#[..],
            br#"{"fullpath":"abc"#,
            br#"{"fullpath":"ab\"#,
            br#"{"fullpath":"\u12"}"#,
            br#"{"fullpath":"\uzzzz"}"#,
            br#"{"fullpath":5}"#,
            br#"{"fullpath"}"#,
            b"\"fullpath\"",
            b"",
            b"\"",
            br#"{"fullpath":"\ud800"}"#,
        ] {
            let _ = json_string(json, "fullpath");
        }
        assert_eq!(json_string(br#"{"fullpath":"\ud800"}"#, "fullpath").as_deref(), Some("\u{fffd}"));
    }
}
