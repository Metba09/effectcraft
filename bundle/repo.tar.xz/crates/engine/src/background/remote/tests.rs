use super::*;
use crate::Session;
use serde_json::json;

fn round<T: Serialize + for<'de> Deserialize<'de>>(v: &T) -> T {
    serde_json::from_str(&serde_json::to_string(v).unwrap()).unwrap()
}

#[test]
fn diff_and_patch_round_trip() {
    let a = json!({"a": 1, "b": [1, 2, {"c": null}], "d": {"e": "x", "f": [1]}, "g": null});
    let b = json!({"a": 2, "b": [1, 3, {"c": 4}], "d": {"f": [1, 2]}, "g": null, "h": {"i": null}});
    let ops = diff(&a, &b);
    assert!(!ops.is_empty());
    let mut x = a.clone();
    patch(&mut x, &round(&ops)).unwrap();
    assert_eq!(x, b);
    // Removal and the reverse direction.
    let mut y = b.clone();
    patch(&mut y, &diff(&b, &a)).unwrap();
    assert_eq!(y, a);
    assert!(diff(&a, &a).is_empty());
    // A whole-document change.
    let mut z = json!(1);
    patch(&mut z, &diff(&json!(1), &json!([1]))).unwrap();
    assert_eq!(z, json!([1]));
    // A patch for another document fails cleanly.
    assert!(patch(&mut json!(3), &diff(&a, &b)).is_err());
}

fn server(s: &Session) -> FrameServer {
    FrameServer::new(s.footage.clone(), s.expr.clone())
}

/// Pixels the page itself would render.
fn local(s: &Session, comp: ItemId, t: Tick, opts: RenderOpts) -> Vec<u8> {
    let mut r = Renderer::new(&s.project, s.footage.as_ref(), opts);
    r.expr = s.expr.as_deref();
    rgba8_premultiplied(&r.comp_frame(comp, t))
}

/// Layer buffers through the disk store: a worker's slow buffers queue up as entries; the
/// page plans what another worker fetches before its frame (recent misses on disk); that
/// worker's mid-render lookups find them and the pixels match.
#[test]
fn layer_buffers_go_through_the_disk_store() {
    use effectcraft_render::disk_cache::{DiskIndex, Kind, LayerPrefetch};
    let mut s = Session::default();
    s.execute("file.openDemoProject", json!({})).unwrap();
    let comp = s.active_comp_id().unwrap();
    let opts = RenderOpts { scale: 0.25, ..Default::default() };
    let t = Tick::from_seconds_f64(1.0);
    let req = |id: u64, layers: bool, prefetch: Vec<String>| {
        round(&FrameMsg::Render { id, revision: s.revision, comp, time: t, opts: Box::new(opts), disk: None, layers, prefetch })
    };
    let worker = || {
        let mut w = server(&s);
        let store = Arc::new(PrefetchStore::new(64 << 20).with_min_ms(0));
        w.set_layer_store(Some(store.clone()));
        let mut m = Mirror::default();
        assert!(w.handle(round(&m.sync(s.revision, &s.project).unwrap())).is_empty());
        (w, store)
    };
    let unhex = |v: &[String]| v.iter().map(|k| u128::from_str_radix(k, 16).unwrap()).collect::<Vec<u128>>();
    // Worker A: everything misses; its buffers queue up for the disk.
    let (mut a, store_a) = worker();
    let out = a.handle(req(1, true, vec![]));
    let (FrameReply::Frame { layer_misses, layer_hits, .. }, Some(px_a)) = &out[0] else { panic!("{:?}", out[0].0) };
    assert!(!layer_misses.is_empty() && layer_hits.is_empty());
    let writes = store_a.take_writes();
    assert!(!writes.is_empty());
    // Sealed with the files each buffer was made of (none here: the demo reads no footage).
    assert!(writes.iter().all(|(_, e)| effectcraft_render::disk_cache::read_layer_entry(e).is_some_and(|(_, f)| f.is_empty())));
    let mut index = DiskIndex::default();
    let mut disk = std::collections::HashMap::new();
    for (k, e) in writes {
        index.insert(Kind::Layer, k, e.len() as u64);
        disk.insert(k, e);
    }
    index.insert(Kind::Frame, 1, 10);
    // The page: recent misses that are on disk, most recent first.
    let mut plan = LayerPrefetch::default();
    plan.note_misses(unhex(layer_misses));
    let keys = plan.plan(&index, 64);
    assert!(!keys.is_empty() && keys.len() <= index.len());
    // Worker B fetches them before its first frame: its lookups hit.
    let (mut b, store_b) = worker();
    for k in &keys {
        assert!(store_b.provide(*k, &disk[k]));
    }
    assert!(!store_b.provide(1, b"damaged"));
    let out = b.handle(req(1, true, keys.iter().map(|k| format!("{k:032x}")).collect()));
    let (FrameReply::Frame { layer_misses: mb, layer_hits: hb, .. }, Some(px_b)) = &out[0] else { panic!("{:?}", out[0].0) };
    assert_eq!(unhex(hb).len(), keys.len(), "every fetched buffer was used");
    assert!(mb.len() < layer_misses.len());
    assert_eq!(px_a, px_b);
    assert_eq!(*px_b, local(&s, comp, t, opts));
    // Nothing new to write: what B rendered itself was rendered by A too.
    assert!(store_b.take_writes().iter().all(|(k, _)| disk.contains_key(k)));
    // Without `layers` the store is not consulted.
    let (mut c, store_c) = worker();
    c.handle(req(1, false, vec![]));
    assert!(store_c.take_misses().is_empty() && store_c.take_writes().is_empty());
    // Purge empties the store.
    b.handle(round(&FrameMsg::Purge));
    assert!(!store_b.has(keys[0]));
    // LRU across frames and layers in the shared index: a touched layer outlives the frame.
    index.touch(Kind::Layer, keys[0]);
    let order = index.lru_order();
    assert_eq!(order.last(), Some(&(Kind::Layer, keys[0])));
    assert!(order.iter().position(|e| *e == (Kind::Frame, 1)).unwrap() < order.len() - 1);
}

#[test]
fn replica_follows_edits_through_diffs_and_renders_the_same_frames() {
    let mut s = Session::default();
    s.execute("file.openDemoProject", json!({})).unwrap();
    let comp = s.active_comp_id().unwrap();
    let opts = RenderOpts { scale: 0.25, guides: true, ..Default::default() };
    let mut m = Mirror::default();
    let mut w = server(&s);
    let send = |m: FrameMsg, w: &mut FrameServer| w.handle(round(&m));
    // First sync: the whole project.
    let first = m.sync(s.revision, &s.project).unwrap();
    assert!(matches!(first, FrameMsg::Project { .. }));
    assert!(send(first, &mut w).is_empty());
    assert!(m.sync(s.revision, &s.project).is_none(), "nothing new");
    let t = Tick::from_seconds_f64(1.0);
    let render = |w: &mut FrameServer, rev: u64, id: u64| {
        w.handle(round(&FrameMsg::Render { id, revision: rev, comp, time: t, opts: Box::new(opts), disk: None, layers: false, prefetch: vec![] }))
    };
    let out = render(&mut w, s.revision, 1);
    let (FrameReply::Frame { id, width, height, .. }, Some(px)) = &out[0] else { panic!("{:?}", out[0].0) };
    assert_eq!((*id, *width as usize * *height as usize * 4), (1, px.len()));
    assert_eq!(*px, local(&s, comp, t, opts));
    // An edit travels as a small diff; the replica renders the edited frame.
    s.execute("layer.newSolid", json!({"color": "#ff8800", "name": "Orange"})).unwrap();
    let msg = m.sync(s.revision, &s.project).unwrap();
    let FrameMsg::Patch { ops, .. } = &msg else { panic!("expected a patch") };
    assert!(!ops.is_empty() && serde_json::to_string(ops).unwrap().len() < s.project.to_json().len() / 2);
    assert!(send(msg, &mut w).is_empty());
    assert_eq!(**w.project().unwrap(), *s.project);
    let out = render(&mut w, s.revision, 2);
    assert_eq!(out[0].1.as_deref(), Some(&local(&s, comp, t, opts)[..]));
    // A request for another revision is refused as stale.
    let out = render(&mut w, s.revision + 7, 3);
    assert!(matches!(out[0].0, FrameReply::Failed { id: 3, stale: true, .. }));
    // A patch from the wrong base asks for a resync; the mirror then sends the project.
    let bad = FrameMsg::Patch { from: 999, revision: 1000, ops: vec![] };
    assert!(matches!(send(bad, &mut w)[0].0, FrameReply::Resync { .. }));
    m.reset();
    assert!(matches!(m.sync(s.revision, &s.project), Some(FrameMsg::Project { .. })));
}

#[test]
fn frame_messages_round_trip() {
    for m in [
        FrameMsg::Purge,
        FrameMsg::Segs { segs: vec![SegData { key: 7, data: "AAAA".into() }] },
        FrameMsg::Render {
            id: 3,
            revision: 4,
            comp: ItemId(2),
            time: Tick::from_seconds_f64(0.5),
            opts: Box::new(RenderOpts { scale: 0.5, draft: true, roi: Some([1.0, 2.0, 3.0, 4.0]), ..Default::default() }),
            disk: Some(format!("{:032x}", 0xabcdu128)),
            layers: true,
            prefetch: vec![format!("{:032x}", 7u128)],
        },
    ] {
        let a = serde_json::to_string(&m).unwrap();
        assert_eq!(serde_json::to_string(&round(&m)).unwrap(), a);
        assert!(a.starts_with("{\"type\":"), "{a}");
    }
    for r in [
        FrameReply::Frame { id: 1, width: 2, height: 3, ms: 4.5, passes: 2, gpu: true, layer_misses: vec!["0a".into()], layer_hits: vec![] },
        FrameReply::Stored { key: "00ff".into(), bytes: 9, layer: false },
        FrameReply::Stored { key: "00fe".into(), bytes: 8, layer: true },
        FrameReply::Info { gpu: Some("Adapter (BrowserWebGpu)".into()), error: None },
        FrameReply::Failed { id: 1, error: "x".into(), stale: true },
        FrameReply::Resync { error: "y".into() },
    ] {
        assert_eq!(round(&r), r);
    }
}

/// An accelerator with deferred readbacks: a GPU effect chain is "read back" one
/// [`Deferred::settle`] after it was first asked for (computed with the CPU effects, so the
/// finished frame equals the CPU render); until then it misses and returns its input.
#[derive(Default)]
struct Deferred {
    ready: std::sync::Mutex<std::collections::HashSet<u64>>,
    asked: std::sync::Mutex<std::collections::HashSet<u64>>,
    gate: Arc<std::sync::atomic::AtomicBool>,
    chains: std::sync::atomic::AtomicUsize,
    begins: std::sync::atomic::AtomicUsize,
    ends: std::sync::atomic::AtomicUsize,
    auto: effectcraft_render::AutoPick,
}

impl Deferred {
    fn settle(&self) {
        let asked: Vec<u64> = self.asked.lock().unwrap().drain().collect();
        self.ready.lock().unwrap().extend(asked);
    }
}

impl Accelerator for Deferred {
    fn name(&self) -> String {
        "deferred".into()
    }
    fn comp_frame(&self, _: &Renderer, _: ItemId, _: Tick) -> Option<Image> {
        None
    }
    fn supports_effect(&self, id: &str) -> bool {
        effectcraft_effects::GPU_EFFECTS.contains(&id)
    }
    fn effects(&self, chain: &[effectcraft_render::FxStep], buf: &effectcraft_effects::Buf, levels: Option<f32>) -> Option<effectcraft_effects::Buf> {
        use std::hash::{Hash, Hasher};
        let mut h = std::collections::hash_map::DefaultHasher::new();
        for s in chain {
            s.spec.id.hash(&mut h);
            s.ctx.time.to_bits().hash(&mut h);
        }
        (buf.img.width, buf.img.height).hash(&mut h);
        for p in &buf.img.data {
            for c in p {
                c.to_bits().hash(&mut h);
            }
        }
        let key = h.finish();
        if !self.ready.lock().unwrap().contains(&key) {
            self.asked.lock().unwrap().insert(key);
            self.gate.store(true, std::sync::atomic::Ordering::Relaxed);
            return Some(buf.clone());
        }
        self.chains.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let mut b = buf.clone();
        for s in chain {
            b = effectcraft_effects::apply(s.spec, &s.ctx, b);
            if let Some(l) = levels {
                effectcraft_render::color::quantize(&mut b.img, l);
            }
        }
        Some(b)
    }
    fn auto_pick(&self) -> Option<&effectcraft_render::AutoPick> {
        Some(&self.auto)
    }
    fn frame_begin(&self) {
        self.begins.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        self.ready.lock().unwrap().clear();
    }
    fn frame_end(&self) {
        self.ends.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
    }
    fn pass_begin(&self) {
        self.gate.store(false, std::sync::atomic::Ordering::Relaxed);
    }
    fn pass_missed(&self) -> bool {
        self.gate.load(std::sync::atomic::Ordering::Relaxed)
    }
    fn miss_gate(&self) -> Option<Arc<std::sync::atomic::AtomicBool>> {
        Some(self.gate.clone())
    }
}

#[test]
fn deferred_readbacks_render_in_passes() {
    let mut s = Session::default();
    s.execute("file.openDemoProject", json!({})).unwrap();
    let comp = s.active_comp_id().unwrap();
    s.execute("layer.newSolid", json!({"color": "#3388ff", "name": "Blue", "width": 200, "height": 120})).unwrap();
    s.execute("effect.apply", json!({"effect": "ec.blur.gaussian"})).unwrap();
    s.execute("effect.apply", json!({"effect": "ec.stylize.glow"})).unwrap();
    s.execute("layer.newSolid", json!({"color": "#ffcc00", "name": "Yellow", "width": 80, "height": 80})).unwrap();
    s.execute("effect.apply", json!({"effect": "ec.color.levels"})).unwrap();
    let opts = RenderOpts { scale: 0.25, backend: Backend::Gpu, ..Default::default() };
    let t = Tick::from_seconds_f64(1.0);
    let mut w = server(&s);
    let acc = Arc::new(Deferred::default());
    w.set_accel(Some(acc.clone()));
    let mut m = Mirror::default();
    w.handle(round(&m.sync(s.revision, &s.project).unwrap()));
    let req = |id| round(&FrameMsg::Render { id, revision: s.revision, comp, time: t, opts: Box::new(opts), disk: None, layers: false, prefetch: vec![] });
    assert!(w.handle(req(1)).is_empty() && w.waiting(), "the first pass misses");
    let mut out = vec![];
    for _ in 0..10 {
        acc.settle();
        out = w.resume();
        if !w.waiting() {
            break;
        }
    }
    let (FrameReply::Frame { id: 1, passes, gpu: true, .. }, Some(px)) = &out[0] else { panic!("{:?}", out.first().map(|o| &o.0)) };
    assert!(*passes >= 2, "{passes}");
    assert!(acc.chains.load(std::sync::atomic::Ordering::Relaxed) >= 2);
    // The same pixels as the CPU: no placeholder survived, in the frame or the layer cache.
    assert_eq!(*px, local(&s, comp, t, RenderOpts { backend: Backend::Cpu, ..opts }));
    let out = w.handle(req(2));
    let out = if out.is_empty() {
        acc.settle();
        w.resume()
    } else {
        out
    };
    assert_eq!(out[0].1.as_deref(), Some(&px[..]));
    // CPU requests never touch the accelerator; Auto times whole frames.
    let cpu = RenderOpts { backend: Backend::Cpu, ..opts };
    let out =
        w.handle(round(&FrameMsg::Render { id: 3, revision: s.revision, comp, time: t, opts: Box::new(cpu), disk: None, layers: false, prefetch: vec![] }));
    assert!(matches!(out[0].0, FrameReply::Frame { id: 3, passes: 1, gpu: false, .. }));
    for id in 4..12 {
        let auto = RenderOpts { backend: Backend::Auto, ..opts };
        let mut out =
            w.handle(round(&FrameMsg::Render { id, revision: s.revision, comp, time: t, opts: Box::new(auto), disk: None, layers: false, prefetch: vec![] }));
        while w.waiting() {
            acc.settle();
            out = w.resume();
        }
        assert_eq!(out[0].1.as_deref(), Some(&px[..]), "frame {id}");
    }
    let st = acc.auto.stats(effectcraft_render::AutoKey::new(comp, opts.scale, false)).unwrap();
    assert!(st.cpu_frames > 0 && st.gpu_frames > 0, "{st:?}");
}

/// `frame_begin` and `frame_end` stay paired: early fails (before `frame_begin`), a pending frame replaced by a new render, a finished multi-pass frame, and a CPU frame.
#[test]
fn every_frame_begin_has_a_frame_end() {
    use std::sync::atomic::Ordering::Relaxed;
    let mut s = Session::default();
    s.execute("file.openDemoProject", json!({})).unwrap();
    let comp = s.active_comp_id().unwrap();
    s.execute("layer.newSolid", json!({"color": "#3388ff", "name": "Blue", "width": 200, "height": 120})).unwrap();
    s.execute("effect.apply", json!({"effect": "ec.blur.gaussian"})).unwrap();
    s.execute("effect.apply", json!({"effect": "ec.stylize.glow"})).unwrap();
    s.execute("layer.newSolid", json!({"color": "#ffcc00", "name": "Yellow", "width": 80, "height": 80})).unwrap();
    s.execute("effect.apply", json!({"effect": "ec.color.levels"})).unwrap();
    let opts = RenderOpts { scale: 0.25, backend: Backend::Gpu, ..Default::default() };
    let t = Tick::from_seconds_f64(1.0);
    let mut w = server(&s);
    let acc = Arc::new(Deferred::default());
    w.set_accel(Some(acc.clone()));
    let mut m = Mirror::default();
    w.handle(round(&m.sync(s.revision, &s.project).unwrap()));
    let req = |id, revision, comp, opts: RenderOpts| {
        round(&FrameMsg::Render { id, revision, comp, time: t, opts: Box::new(opts), disk: None, layers: false, prefetch: vec![] })
    };
    let load = || (acc.begins.load(Relaxed), acc.ends.load(Relaxed));
    // Early fails never touch the frame clock.
    assert!(matches!(w.handle(req(1, s.revision + 1, comp, opts))[0].0, FrameReply::Failed { .. }));
    assert!(matches!(w.handle(req(2, s.revision, ItemId(999_999), opts))[0].0, FrameReply::Failed { .. }));
    assert_eq!(load(), (0, 0));
    // First GPU pass misses and leaves the frame pending.
    assert!(w.handle(req(3, s.revision, comp, opts)).is_empty() && w.waiting());
    assert_eq!(load(), (1, 0));
    // A fail while pending leaves the frame and the counters alone.
    assert!(matches!(w.handle(req(4, s.revision + 1, comp, opts))[0].0, FrameReply::Failed { .. }));
    assert!(w.waiting());
    assert_eq!(load(), (1, 0));
    // A new valid render replaces the pending frame (ends the old one).
    assert!(w.handle(req(5, s.revision, comp, opts)).is_empty() && w.waiting());
    assert_eq!(load(), (2, 1));
    let mut out = vec![];
    for _ in 0..10 {
        acc.settle();
        out = w.resume();
        if !w.waiting() {
            break;
        }
    }
    assert!(matches!(out[0].0, FrameReply::Frame { id: 5, .. }));
    assert_eq!(load(), (2, 2));
    // CPU still pairs begin/end on the accelerator.
    let cpu = RenderOpts { backend: Backend::Cpu, ..opts };
    assert!(matches!(w.handle(req(6, s.revision, comp, cpu))[0].0, FrameReply::Frame { id: 6, .. }));
    assert_eq!(load(), (3, 3));
}

/// Footage that reads one file from memory (the browser's file table) for every frame.
struct OneVirtualFile {
    /// Tell which files it reads (else every render's list is incomplete).
    records: bool,
}

impl FootageSource for OneVirtualFile {
    fn frame(&self, _: ItemId, _: &effectcraft_project::Footage, _: Tick) -> Option<Arc<Image>> {
        Some(Arc::new(Image::filled(4, 4, [1.0, 0.5, 0.0, 1.0])))
    }
    fn recording(&self, reads: &ReadLog, f: &mut dyn FnMut()) {
        if self.records {
            reads.note(effectcraft_render::reads::ReadFile::new("/clip.png", effectcraft_render::reads::FileStamp::Virtual));
        } else {
            reads.mark_incomplete();
        }
        f()
    }
}

/// The worker hands the transport the files each frame read, so its disk entry keeps them; the
/// page reads the entry back only while those files are unchanged. A frame whose files can't
/// all be named is not stored (#3184).
#[test]
fn the_worker_reports_the_files_of_each_frame_for_its_disk_entry() {
    use effectcraft_project::{Comp, Footage, ItemKind, LayerSource, Project, build};
    use effectcraft_render::disk_cache::{frame_entry, read_frame_entry};
    use effectcraft_time::FrameRate;
    let mut p = Project::default();
    let f = Footage { path: "/clip.png".into(), width: 4, height: 4, duration: Tick::from_seconds_f64(1.0), has_video: true, ..Default::default() };
    let fid = p.add_item("clip.png", effectcraft_color::Label::None, None, ItemKind::Footage(f));
    let mut comp = Comp::new(4, 4, FrameRate::FPS_30, Tick::from_seconds_f64(1.0));
    comp.layers = vec![build::layer(&mut p, &comp, "clip", LayerSource::Footage { item: fid }, (4, 4), None)].into();
    let cid = p.add_item("C", effectcraft_color::Label::None, None, ItemKind::Comp(comp.into()));
    let id = |mark: u64| move |path: &str| (path == "/clip.png").then_some((10, mark));
    let (one, two) = (id(1), id(2));
    for records in [true, false] {
        let mut w = FrameServer::new(Arc::new(OneVirtualFile { records }), None);
        w.set_virtual_id(Some(Arc::new(one)));
        let mut m = Mirror::default();
        assert!(w.handle(round(&m.sync(1, &p).unwrap())).is_empty());
        assert!(w.take_files().is_none(), "no frame yet");
        let out = w.handle(round(&FrameMsg::Render {
            id: 1,
            revision: 1,
            comp: cid,
            time: Tick::ZERO,
            opts: Box::default(),
            disk: Some(format!("{:032x}", 5u128)),
            layers: false,
            prefetch: vec![],
        }));
        let (FrameReply::Frame { width, height, .. }, Some(px)) = &out[0] else { panic!("{:?}", out[0].0) };
        let files = w.take_files().expect("the frame's files");
        assert!(w.take_files().is_none(), "taken once");
        let vid = w.virtual_id().cloned();
        let entry = frame_entry(*width, *height, px, &files, vid.as_deref());
        if !records {
            assert!(!files.is_complete() && entry.is_none(), "an incomplete list is not stored");
            continue;
        }
        assert_eq!(files.files().iter().map(|f| &*f.path).collect::<Vec<_>>(), ["/clip.png"]);
        let entry = entry.expect("stored");
        assert_eq!(read_frame_entry(&entry, Some(&one)).map(|f| f.rgba), Some(px.clone()));
        assert!(read_frame_entry(&entry, Some(&two)).is_none(), "the file was replaced: a miss");
    }
}

/// No salt work at all (#3184, replacing the background salt of #3106): syncing a project with a
/// large image sequence nobody shows, patching it and rendering with the layer store never asks
/// the file hook about the sequence (the salt asked about every file at every sync). Only the
/// file the rendered buffer reads is asked about: to store its entry and, in another worker, to
/// check it before the buffer from the store is used.
#[test]
fn the_worker_asks_only_about_the_files_its_buffers_read() {
    use effectcraft_project::{Comp, Footage, FootageKind, ItemKind, LayerSource, Project, build};
    use effectcraft_time::FrameRate;
    use std::sync::Mutex;
    let mut p = Project::default();
    let f = Footage { path: "/clip.png".into(), width: 4, height: 4, has_video: true, ..Default::default() };
    let fid = p.add_item("clip.png", effectcraft_color::Label::None, None, ItemKind::Footage(f));
    let seq = Footage {
        kind: FootageKind::Sequence,
        path: "/seq/f_00000.png".into(),
        sequence: (0..5000).map(|i| format!("/seq/f_{i:05}.png")).collect(),
        width: 4,
        height: 4,
        has_video: true,
        ..Default::default()
    };
    p.add_item("seq", effectcraft_color::Label::None, None, ItemKind::Footage(seq));
    let mut comp = Comp::new(4, 4, FrameRate::FPS_30, Tick::from_seconds_f64(1.0));
    comp.layers = vec![build::layer(&mut p, &comp, "clip", LayerSource::Footage { item: fid }, (4, 4), None)].into();
    let cid = p.add_item("C", effectcraft_color::Label::None, None, ItemKind::Comp(comp.into()));
    let asked: Arc<Mutex<Vec<String>>> = Arc::default();
    let worker = || {
        let mut w = FrameServer::new(Arc::new(OneVirtualFile { records: true }), None);
        let seen = asked.clone();
        w.set_virtual_id(Some(Arc::new(move |path: &str| {
            seen.lock().unwrap().push(path.to_string());
            (path == "/clip.png").then_some((10, 1))
        })));
        let store = Arc::new(PrefetchStore::new(1 << 20).with_min_ms(0));
        w.set_layer_store(Some(store.clone()));
        (w, store)
    };
    let render = |w: &mut FrameServer, revision: u64, prefetch: Vec<String>| {
        let out = w.handle(round(&FrameMsg::Render { id: 1, revision, comp: cid, time: Tick::ZERO, opts: Box::default(), disk: None, layers: true, prefetch }));
        let FrameReply::Frame { layer_hits, .. } = &out[0].0 else { panic!("{:?}", out[0].0) };
        layer_hits.len()
    };
    // Worker A: synced, patched, rendered; its buffer is queued with its file.
    let (mut a, store_a) = worker();
    let mut m = Mirror::default();
    assert!(a.handle(round(&m.sync(1, &p).unwrap())).is_empty());
    let mut edited = p.clone();
    edited.item_mut(cid).unwrap().name = "Renamed".into();
    assert!(a.handle(round(&m.sync(2, &edited).unwrap())).is_empty());
    assert!(asked.lock().unwrap().is_empty(), "syncing looks at no file");
    assert_eq!(render(&mut a, 2, vec![]), 0);
    let writes = store_a.take_writes();
    assert!(!writes.is_empty(), "the clip's buffer is stored");
    // Worker B: fetched before its frame, checked, used.
    let (mut b, store_b) = worker();
    let mut m = Mirror::default();
    assert!(b.handle(round(&m.sync(2, &edited).unwrap())).is_empty());
    for (k, e) in &writes {
        assert!(store_b.provide(*k, e));
    }
    assert!(render(&mut b, 2, writes.iter().map(|(k, _)| format!("{k:032x}")).collect()) > 0, "served from the store");
    let asked = asked.lock().unwrap();
    assert!(!asked.is_empty(), "the hook names the buffer's file");
    assert!(asked.iter().all(|p| p == "/clip.png"), "only the file the buffer read: {:?}", &asked[..asked.len().min(5)]);
}
